package com.lgy.mf_board.controller;

import java.util.ArrayList;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.lgy.mf_board.dto.BoardDTO;
import com.lgy.mf_board.service.BoardService;

@Controller
public class BoardController {

	@Autowired
	private BoardService service;

	@RequestMapping("/board/list")
	public String list(Model model) {

		ArrayList<BoardDTO> list = service.list();
		System.out.println(list);
		model.addAttribute("list", list);
		System.out.println("#@ 이거야 이거");

		return "board/list";
	}

	@RequestMapping("/board/write_view")
	public String write_view() {
		return "board/write_view";
	}

	// 글쓰기 이동
	@RequestMapping("/board/modify_board_write")
	public String modify_board_write(@RequestParam("b_id") int b_id, Model model) {
		BoardDTO dto = service.contentView(b_id);
		model.addAttribute("dto", dto);
		return "board/modify_board_write";
	}

	// 수정 확인
	@RequestMapping("/board/modify_board_write_ok")
	public String modify_board_write_ok(@RequestParam("b_title") String b_title,
			@RequestParam("b_content") String b_content, @RequestParam("b_id") int b_id, Model model) {
		service.modify(b_title, b_content, b_id);
		model.addAttribute("b_id", b_id);
		return "redirect:/board/content_view";
	}

	@RequestMapping("/board/insert_board_write")
	public String insert_board_write(@RequestParam HashMap<String, String> param) {
		System.out.println("insert test");
		service.write(param);
		System.out.println("@# insert param" + param);

		return "redirect:/board/list"; // View를 보내지 않고 경로만 문자열로 반환
	}

	@RequestMapping("/board/content_view")
	public String content_view(@RequestParam("b_id") int b_id, Model model) {
		BoardDTO dto = service.contentView(b_id);
		model.addAttribute("content_view", dto);
		System.out.println("b_id" + b_id);

		return "board/content_view";
	}

	@RequestMapping("/board/delete_board_write")
	public String delete_board_write(@RequestParam HashMap<String, String> param) {
		System.out.println("delete()");
		System.out.println("test1");
		service.delete(param);
		System.out.println("test2");

		return "redirect:/board/list";
	}
}
