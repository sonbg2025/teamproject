package com.lgy.mf_board.service;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Service;

import com.lgy.mf_board.dto.BoardDTO;

@Service
public interface BoardService {
	public ArrayList<BoardDTO> list();

	public void write(HashMap<String, String> param);

	public BoardDTO contentView(int b_id);

	public void modify(@Param("b_title") String b_title, @Param("b_content") String b_content, @Param("b_id") int b_id);

	public void delete(HashMap<String, String> param);
}
